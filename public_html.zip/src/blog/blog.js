// document.addEventListener('DOMContentLoaded', function() {
//     const mobileMenuButton = document.getElementById('mobile-menu-button');
//     const mobileMenu = document.getElementById('mobile-menu');

//     if (mobileMenuButton && mobileMenu) {
//         mobileMenuButton.addEventListener('click', () => {
//             mobileMenu.classList.toggle('hidden');
//             mobileMenu.classList.toggle('block');
//         });
//     } else {
//         console.error('Mobile menu button or menu not found');
//     }
// });

document.addEventListener('DOMContentLoaded', function () {
    const subscribeForm = document.getElementById('subscribe-form');
    if (subscribeForm) {
        subscribeForm.addEventListener('submit', async function (event) {
            event.preventDefault();
            const email = document.getElementById('input-email').value;
            console.log(email);

            try {
                const response = await fetch('http://localhost:3000/subscribe', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({ email }),
                });

                if (response.ok) {
                    alert('Thank you for subscribing!');
                } else {
                    alert('Failed to subscribe. Please try again.');
                }
            } catch (error) {
                console.error('Error:', error);
                alert('An error occurred. Please try again.');
            }
        });
    }
});
